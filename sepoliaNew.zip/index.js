import { ethers } from 'ethers';
import dotenv from 'dotenv';
import chainIds from './constants/chainIds.json' assert { type: "json" };
import bridgeAbi from './constants/bridgeAbi.json' assert { type: "json" };
import nativeOftAbi from './constants/nativeOftAbi.json' assert { type: "json" };
import inquirer from 'inquirer';
import fs from 'fs';
import readline from 'readline';

dotenv.config();

// Load env
const { PRIVATE_KEY, BRIDGE_AMOUNT, ETHEREUM_RPC, ARBITRUM_RPC, OPTIMISM_RPC, SEPOLIA_RPC, GAS_LIMIT } = process.env;

// Network RPC URLs
const rpcUrls = {
    sepolia: SEPOLIA_RPC,
    ethereum: ETHEREUM_RPC,
    arbitrum: ARBITRUM_RPC,
    optimism: OPTIMISM_RPC
};

// Contract addresses and ABIs
const contractAddresses = {
    sepolia: {
        nativeOft: "0x2e5221B0f855Be4ea5Cefffb8311EED0563B6e87",
        swappableBridge: "0x57beDd7eb4C3118669f4F33A3CAe4D4B554f24b7"
    },
    eth: {
        nativeOft: "0xE71bDfE1Df69284f00EE185cf0d95d0c7680c0d4",
        swappableBridge: "0x57beDd7eb4C3118669f4F33A3CAe4D4B554f24b7"
    },
    eth_arb: {
        nativeOft: "0xE71bDfE1Df69284f00EE185cf0d95d0c7680c0d4",
        swappableBridge: "0xfcA99F4B5186D4bfBDbd2C542dcA2ecA4906BA45"
    },
    eth_op: {
        nativeOft: "0xE71bDfE1Df69284f00EE185cf0d95d0c7680c0d4",
        swappableBridge: "0x8352C746839699B1fc631fddc0C3a00d4AC71A17"
    }
};

// Function to read addresses from file
async function readAddressesFromFile() {
    const addresses = [];
    const fileStream = fs.createReadStream('address.txt');
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    for await (const line of rl) {
        const address = line.trim();
        if (address && ethers.isAddress(address)) {
            addresses.push(address);
        }
    }

    return addresses;
}

// Function to show main menu
async function showMainMenu() {
    const response = await inquirer.prompt([
        {
            type: 'list',
            name: 'action',
            message: 'Select bridging direction:',
            choices: [
                'Sepolia to ETH',
                'Sepolia to ETH_Arbitrum',
                'Sepolia to ETH_Optimism',
                'ETH to Sepolia',
                'ETH_Arbitrum to Sepolia',
                'ETH_Optimism to Sepolia',
                'Exit'
            ]
        }
    ]);
    return response.action;
}

// Function to show amount selection menu
async function showAmountMenu() {
    const response = await inquirer.prompt([
        {
            type: 'list',
            name: 'amountChoice',
            message: 'Select amount to bridge:',
            choices: [
                'Use full balance (minus gas)',
                'Enter custom amount'
            ]
        }
    ]);
    return response.amountChoice;
}

// Function to get network details
function getNetworkDetails(network) {
    const networks = {
        'sepolia': {
            rpc: rpcUrls.sepolia,
            chainId: chainIds.sepolia,
            contracts: contractAddresses.sepolia
        },
        'eth': {
            rpc: rpcUrls.ethereum,
            chainId: chainIds.ethereum,
            contracts: contractAddresses.eth
        },
        'eth_arb': {
            rpc: rpcUrls.arbitrum,
            chainId: chainIds.arbitrum,
            contracts: contractAddresses.eth_arb
        },
        'eth_op': {
            rpc: rpcUrls.optimism,
            chainId: chainIds.optimism,
            contracts: contractAddresses.eth_op
        }
    };
    return networks[network];
}

// Function to get user balance and calculate available amount
async function getAvailableBalance(provider, address) {
    const balance = await provider.getBalance(address);
    const balanceInEther = ethers.formatEther(balance);

    // Get gas price and calculate gas cost
    const feeData = await provider.getFeeData();
    const gasPrice = feeData.gasPrice;
    const gasCost = gasPrice * BigInt(GAS_LIMIT);
    const gasFeeInEther = ethers.formatEther(gasCost);
    // Get Native Oft Fee


    // Calculate available amount (balance minus gas)
    const availableAmount = parseFloat(balanceInEther) - parseFloat(gasFeeInEther);

    return {
        balanceInEther,
        gasFeeInEther,
        availableAmount: availableAmount > 0 ? availableAmount : 0,
        balance,
        initialGasCost: gasCost
    };
}

// Function to bridge tokens
async function bridgeTokens(sourceNetwork, targetNetwork) {
    try {
        // Read addresses from file
        const addresses = await readAddressesFromFile();
        let addressesToProcess;


        const sourceDetails = getNetworkDetails(sourceNetwork);
        const targetDetails = getNetworkDetails(targetNetwork);

        // Setup provider and wallet
        const provider = new ethers.JsonRpcProvider(sourceDetails.rpc);
        const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
        const addressTo = wallet.address;

        const { balanceInEther, gasFeeInEther, availableAmount, balance, initialGasCost } = await getAvailableBalance(provider, addressTo);
        console.log(`==============================================`);
        console.log(`Balance: ${balanceInEther} ETH`);
        console.log(`==============================================`);

        if (addresses.length === 0) {
            // console.log('No addresses found in address.txt, using wallet address instead');
            addressesToProcess = [addressTo];
        } else {
            // console.log(`Found ${addresses.length} addresses to process`);
            addressesToProcess = addresses;
        }
        // Get user balance information
        // Show amount selection menu
        const amountChoice = await showAmountMenu();
        let amountInEther;

        if (amountChoice === 'Use full balance (minus gas)') {
            // For full balance, we need to calculate the maximum possible amount
            // that can be bridged after accounting for all fees
            const nativeOft = new ethers.Contract(sourceDetails.contracts.nativeOft, nativeOftAbi, wallet);

            // Start with the full balance minus gas
            let maxAmount = balance - initialGasCost;

            // Estimate native fee for this amount
            const nativeFee = (await nativeOft.estimateSendFee(
                targetDetails.chainId,
                wallet.address,
                maxAmount,
                false,
                "0x"
            )).nativeFee;

            // Calculate final amount (balance - gas - native fee)
            maxAmount = maxAmount - nativeFee;

            // Convert to ether for display
            amountInEther = parseFloat(ethers.formatEther(maxAmount));
            // console.log(`\nMaximum amount that can be bridged: ${amountInEther} ETH`);
        } else {
            const response = await inquirer.prompt([
                {
                    type: 'input',
                    name: 'amount',
                    message: `Enter amount to bridge (max ${availableAmount} ETH):`,
                    validate: (input) => {
                        const value = parseFloat(input);
                        if (isNaN(value) || value <= 0) return 'Please enter a valid positive number';
                        if (value > availableAmount) return `Amount cannot exceed ${availableAmount} ETH`;
                        return true;
                    }
                }
            ]);
            amountInEther = response.amount;
        }

        // Convert amountInEther to uint256
        const amount = ethers.parseEther(String(amountInEther));

        // Use source network's contract addresses
        const nativeOft = new ethers.Contract(sourceDetails.contracts.nativeOft, nativeOftAbi, wallet);
        const bridgeOft = new ethers.Contract(sourceDetails.contracts.swappableBridge, bridgeAbi, wallet);

        // Process each address
        for (const addressRecipient of addressesToProcess) {
            try {
                console.log(`==============================================`);
                console.log(`\nProcessing address: ${addressRecipient}`);
                console.log(`Bridging ${amountInEther} ETH from ${sourceNetwork} to ${targetNetwork}...`);
                console.log(`Destination address: ${addressRecipient}`);
                console.log(`Amount: ${amountInEther} ETH`);

                // Get gas price first
                const feeData = await provider.getFeeData();
                const gasPrice = feeData.gasPrice;
                const transactionGasCost = gasPrice * BigInt(GAS_LIMIT);
                console.log(`==============================================`);
                console.log('Gas cost:', ethers.formatEther(transactionGasCost), 'ETH');

                // Calculate native fee
                const nativeFee = (await nativeOft.estimateSendFee(targetDetails.chainId, addressRecipient, amount, false, "0x")).nativeFee;
                console.log('Native fee:', ethers.formatEther(nativeFee), 'ETH');

                // Calculate total fees
                const totalFees = nativeFee + transactionGasCost;
                console.log('Total fees:', ethers.formatEther(totalFees), 'ETH');

                // Calculate amountIn (amount minus native fee)
                const amountIn = amount - nativeFee - transactionGasCost * 2n;
                console.log('Amount in:', ethers.formatEther(amountIn), 'ETH');

                // Calculate total value needed
                const totalValue = amount + nativeFee;
                console.log('Total value needed:', ethers.formatEther(totalValue), 'ETH');
                console.log(`==============================================\n`);

                // Verify if user has enough balance
                if (balance < totalValue + transactionGasCost) {
                    console.error(`Insufficient balance for address ${addressRecipient}. Skipping...`);
                    continue;
                }
                if (targetNetwork === 'eth_arb' || targetNetwork === 'eth_op') {
                    console.log('Swap and bridge is not supported yet, trying to bridge..');
                    console.log(`==============================================`);
                    const tx = await bridgeOft.bridge(
                        amountIn,
                        targetDetails.chainId,
                        addressRecipient,
                        addressTo,
                        ethers.ZeroAddress,
                        "0x",
                        {
                            value: totalValue,
                            gasPrice: gasPrice,
                            gasLimit: GAS_LIMIT
                        }
                    );
                    console.log(`Bridge tx ${tx.hash}`);
                    await tx.wait();
                    console.log(`Bridge completed for address ${addressRecipient}!`);

                    await new Promise(resolve => setTimeout(resolve, 5000));
                    continue;
                }
                const tx = await bridgeOft.swapAndBridge(
                    amountIn,                  // amountIn (amount minus native fee)
                    "0",                       // amountOutMin
                    targetDetails.chainId,     // dstChainId
                    addressRecipient,           // to
                    addressTo,                 // refundAddress
                    ethers.ZeroAddress,        // zroPaymentAddress
                    "0x",                      // adapterParams
                    {
                        value: totalValue,     // amount + native fee
                        gasPrice: gasPrice,    // use current gas price
                        gasLimit: GAS_LIMIT
                    }
                );

                console.log(`swapAndBridge tx ${tx.hash}`);
                await tx.wait();
                console.log(`Bridge completed for address ${addressRecipient}!`);

                // Add a small delay between transactions
                await new Promise(resolve => setTimeout(resolve, 5000));
            } catch (error) {
                console.error(`Error processing address ${addressRecipient}:`, error.message);
                if (error.data) {
                    console.error("Revert data:", error.data);
                }
                // Continue with next address even if this one fails
                continue;
            }
        }
    } catch (error) {
        console.error("Error bridging tokens:", error.message);
    }
}

// Main function to handle menu and actions
async function main() {
    while (true) {
        const action = await showMainMenu();

        switch (action) {
            case 'Sepolia to ETH':
                await bridgeTokens('sepolia', 'eth');
                break;
            case 'Sepolia to ETH_Arbitrum':
                await bridgeTokens('sepolia', 'eth_arb');
                break;
            case 'Sepolia to ETH_Optimism':
                await bridgeTokens('sepolia', 'eth_op');
                break;
            case 'ETH to Sepolia':
                await bridgeTokens('eth', 'sepolia');
                break;
            case 'ETH_Arbitrum to Sepolia':
                await bridgeTokens('eth_arb', 'sepolia');
                break;
            case 'ETH_Optimism to Sepolia':
                await bridgeTokens('eth_op', 'sepolia');
                break;
            case 'Exit':
                console.log('Exiting...');
                return;
        }

        // Add a small delay between actions
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

// Run the main function
main();
