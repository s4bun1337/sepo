# Token Bridge Application

A Node.js application for bridging tokens between Ethereum, Sepolia, Arbitrum, and Optimism networks.

## Features

- Bridge tokens between multiple networks:
  - Sepolia ↔ Ethereum
  - Sepolia ↔ Arbitrum
  - Sepolia ↔ Optimism
- Support for multiple recipient addresses via `address.txt`
- Automatic gas fee calculation
- Option to use full balance (minus gas fees)
- Custom amount bridging
- Detailed transaction information display

## Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- A wallet with ETH on the source network
- Private key for the wallet

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd <repository-directory>
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file in the root directory with the following variables:
```env
PRIVATE_KEY=your_private_key_here
ETHEREUM_RPC=your_ethereum_rpc_url
ARBITRUM_RPC=your_arbitrum_rpc_url
OPTIMISM_RPC=your_optimism_rpc_url
SEPOLIA_RPC=your_sepolia_rpc_url
GAS_LIMIT=300000
```

## Usage

### Setting Up Recipient Addresses

1. Create an `address.txt` file in the root directory
2. Add recipient addresses, one per line:
```
0x1234...
0x5678...
```

If no addresses are provided in `address.txt`, the application will use the wallet address from private key as the recipient.

### Running the Application

1. Start the application:
```bash
node index.js
```

2. Follow the interactive menu to:
   - Select the bridging direction
   - Choose between using full balance or entering a custom amount
   - View transaction details and confirmations

### Bridging Options

1. **Sepolia to ETH**: Bridge tokens from Sepolia to Ethereum mainnet
2. **Sepolia to ETH_Arbitrum**: Bridge tokens from Sepolia to Arbitrum
3. **Sepolia to ETH_Optimism**: Bridge tokens from Sepolia to Optimism
4. **ETH to Sepolia**: Bridge tokens from Ethereum mainnet to Sepolia
5. **ETH_Arbitrum to Sepolia**: Bridge tokens from Arbitrum to Sepolia
6. **ETH_Optimism to Sepolia**: Bridge tokens from Optimism to Sepolia

### Amount Selection

- **Use full balance (minus gas)**: Automatically calculates the maximum amount that can be bridged after accounting for gas fees
- **Enter custom amount**: Allows you to specify a custom amount to bridge

## Transaction Information

For each transaction, the application displays:
- Current balance
- Gas cost
- Native fee
- Total fees
- Amount being bridged
- Total value needed
- Transaction hash
- Transaction status

## Important Notes

1. Ensure you have sufficient ETH in your wallet for gas fees
2. The application automatically adds a 5-second delay between transactions
3. For Arbitrum and Optimism bridges, the application uses the `bridge` function instead of `swapAndBridge`
4. Transaction fees include:
   - Network gas fees
   - Native bridge fees
   - Additional buffer for transaction safety

## Error Handling

The application includes error handling for:
- Insufficient balance
- Invalid addresses
- Network issues
- Transaction failures

If a transaction fails for one address, the application will continue processing the remaining addresses.

## Security

- Never share your private key
- Keep your `.env` file secure
- Verify transaction details before confirming

## Support

For issues or questions, please open an issue in the repository. 